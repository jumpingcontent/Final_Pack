For our group Wikinets we're just running into some issues with the final deployment but plan to meet again before class tomorrow to 
hopefully figure them out.

I'll be helping by giving input and documentation as much of the process as reasonable.
