I'm currently attempting to compile a 'Build: Passing' project to Sootsplash and then push it to this repository.

After a bit of a search I did see the repo https://github.com/dwyl/repo-badges as a introductory guide on the badging process.

I haven't yet found a good C open source git repo to compile on Sootsplash and then push to this repo but I'm currently in the process 
of that.
