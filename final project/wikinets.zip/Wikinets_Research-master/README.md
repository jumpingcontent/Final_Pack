# Wikinets_Research

We made a good attempt to install Mediawiki but for this project we've decided Moinmoin is a better option. Attached in this repo are files related to our attempt that I've placed an 'archive' style filename tag to.

Here's a link to our second attempt:
https://github.com/jumpingcontent/Wikinets_Moinmoin

// Sadly, we gave a good attempt but the Moinmoin project above wasn't compatible with the Apache server, at least in its current configuration.

**Here's a link to our third and final attempt:
https://github.com/jumpingcontent/Postfixers**

**// This attempt looks to be successful!**
