# week13

For this week I put ch 13 in the .bashrc file
