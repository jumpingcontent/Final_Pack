# Wikinets_Moinmoin

# Welcome to our Wikinets Moinmoin wiki

Hello! This is our main page for our Wikinets project now based on Moinmoin.

Rather than re-forking the forked Wikinets Research repo that we made, we'll have a brand new repo here to house important and useful information for our Moinmoin deployment. For archive and references here was our previous attempt that we tried with Mediawiki: https://github.com/jumpingcontent/Wikinets_Research

We made a good attempt to install Mediawiki but for this project we've decided Moinmoin is a better option. Attached in this repo are files related to our attempt that I've placed an 'archive' style filename tag to.

// Sadly this Moinmoin attempt didn't work and thus I've given each file here archive tags for reference later. Below is the final and successful attempt for our project.

**Here's a link to our third and final attempt: https://github.com/jumpingcontent/Postfixers**

**// This attempt looks to be successful!**
