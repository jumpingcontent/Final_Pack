Here is the team report for our group Postfix project for school!

--------------------------------------

Our team name: Postfix

--------------------------------------

Service: We'll run and test the Postfix email service that already currently installed and document the entire process through.

--------------------------------------

Group roles: Here are some roles below with a bit of info on how each person will go ahead with them.

* Research: Kasia

We'll look into the process of running Postfix and each step.

* Documentation: Ron

We'll make sure to thoroughly document as much of our group status and progress as reasonably possibly while also making further documentation to help prospective users have good reason to use our service.

* Testing: Yasir

We'll run the Postfix server and test each function. We'll comprehensively run deployment testing on each port and service to ensure the services work well. One of the main goals is to ensure uptime and functionality and notify other members of any issues.

* Support: Juan

We'll work with each group member depending on which items above need contributions while also working with the team ensuring that we're following the basic group framework.

--------------------------------------

Communication: We'll keep in touch both through weekly/bi-weekly meetings and also a continuous group text chat.

--------------------------------------

Tasks needed to build: We are planning to use our class server for deployment of our service.

--------------------------------------

Protocols being used: We'll be using SMTP and possibly SMTPS.
